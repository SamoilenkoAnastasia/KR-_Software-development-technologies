package ua.kpi.personal.repo;

import ua.kpi.personal.model.*;
import ua.kpi.personal.util.Db;
import ua.kpi.personal.model.analytics.ReportParams;
import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.sql.Date;
import java.sql.Types;

public class TransactionDao {

    private final CategoryDao categoryDao = new CategoryDao();
    private final AccountDao accountDao = new AccountDao();
    private final UserDao userDao = new UserDao();

    private final String SELECT_FIELDS = "t.id, t.amount, t.type, t.description, t.created_at, t.category_id, t.account_id, t.user_id, t.currency, t.template_id, t.trans_date, t.budget_id, t.created_by_user_id";


    public List<Transaction> findTransactionsByDateRange(ReportParams params, Long budgetId) {
        var list = new ArrayList<Transaction>();

        List<Account> allAccounts = accountDao.findByBudgetId(budgetId);
        List<User> budgetUsers = userDao.findByBudgetId(budgetId);

        Long currentUserId = budgetUsers.stream()
                                        .map(User::getId)
                                        .findFirst()
                                        .orElse(0L);
        List<Category> allCategories = categoryDao.findByUserId(currentUserId); 
        CategoryCache.updateCache(allCategories);

        String sql = "SELECT " + SELECT_FIELDS + " FROM transactions t WHERE t.budget_id = ? AND t.created_at BETWEEN ? AND ? ORDER BY t.created_at DESC";
        try (Connection c = Db.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {

            ps.setLong(1, budgetId);
            ps.setTimestamp(2, Timestamp.valueOf(params.getStartDate().atStartOfDay()));
            ps.setTimestamp(3, Timestamp.valueOf(params.getEndDate().plusDays(1).atStartOfDay().minusNanos(1)));

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Transaction t = mapResultSetToTransaction(rs, allAccounts, budgetUsers);
                    list.add(t);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new RuntimeException("������� �� ��� ��������� ���������� �� ������: " + e.getMessage());
        }
        return list;
    }

    public Transaction findById(Long id, long userId) {
        if (id == null) return null;

        String sql = "SELECT " + SELECT_FIELDS + " FROM transactions t WHERE t.id = ? AND t.user_id = ?";

        try (Connection c = Db.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {

            ps.setLong(1, id);
            ps.setLong(2, userId);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    Long catId = rs.getLong("category_id");
                    if (!rs.wasNull()) {
                         categoryDao.findById(catId); 
                    }
                    
                    return mapResultSetToTransaction(rs, new ArrayList<>(), new ArrayList<>());
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new RuntimeException("������� �� ��� ��������� ���������� �� id/userId: " + e.getMessage());
        }
        return null;
    }

    public List<Transaction> findByBudgetId(Long budgetId){
        var list = new ArrayList<Transaction>();

        List<Account> allAccounts = accountDao.findByBudgetId(budgetId);
        List<User> budgetUsers = userDao.findByBudgetId(budgetId);

        Long currentUserId = budgetUsers.stream()
                                        .map(User::getId)
                                        .findFirst()
                                        .orElse(0L);
        List<Category> allCategories = categoryDao.findByUserId(currentUserId); 
        CategoryCache.updateCache(allCategories);


        String sql = "SELECT " + SELECT_FIELDS + " FROM transactions t WHERE t.budget_id = ? ORDER BY t.created_at DESC";
        try(Connection c = Db.getConnection();
            PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setLong(1, budgetId);
            try (ResultSet rs = ps.executeQuery()) {
                while(rs.next()){
                    Transaction t = mapResultSetToTransaction(rs, allAccounts, budgetUsers);
                    list.add(t);
                }
            }
        } catch(SQLException e){
            e.printStackTrace();
            throw new RuntimeException("������� �� ��� ��������� ���������� �� budgetId: " + e.getMessage());
        }
        return list;
    }

    private Transaction mapResultSetToTransaction(ResultSet rs, List<Account> allAccounts, List<User> budgetUsers) throws SQLException {
        Transaction t = new Transaction();

        t.setId(rs.getLong("id"));
        t.setAmount(rs.getDouble("amount"));
        t.setType(rs.getString("type"));
        t.setDescription(rs.getString("description"));

        Timestamp ts = rs.getTimestamp("created_at");
        if(ts != null) t.setCreatedAt(ts.toLocalDateTime());

        Date transDate = rs.getDate("trans_date");
        if(transDate != null) t.setTransDate(transDate.toLocalDate());

        Long templateId = rs.getLong("template_id");
        if (!rs.wasNull()) {
            t.setTemplateId(templateId);
        }

        Long catId = rs.getLong("category_id");
        if (!rs.wasNull()) {
            t.setCategory(CategoryCache.getById(catId));
        }

        Long accId = rs.getLong("account_id");
        if (!rs.wasNull()) {
            Account foundAccount = allAccounts.stream()
                                             .filter(acc -> acc.getId().equals(accId))
                                             .findFirst()
                                             .orElse(null);
            if (foundAccount == null && accId != 0 && allAccounts.isEmpty()) {
                foundAccount = accountDao.findById(accId);
            }
            t.setAccount(foundAccount);
        }

        Long ownerUserId = rs.getLong("user_id");
        if (!rs.wasNull()) {
            User owner = null;

            if (budgetUsers != null) {
                owner = budgetUsers.stream()
                       .filter(user -> user.getId().equals(ownerUserId))
                       .findFirst()
                       .orElse(null);
            }
            if (owner == null) {
                owner = userDao.findById(ownerUserId);
            }
            t.setUser(owner);
        }

        Long createdByUserId = (Long) rs.getObject("created_by_user_id");

        if (createdByUserId != null) { 
            User createdBy = null;

            if (budgetUsers != null) {
                createdBy = budgetUsers.stream()
                       .filter(user -> user.getId().equals(createdByUserId))
                       .findFirst()
                       .orElse(null);
            }

            if (createdBy == null) {
                createdBy = userDao.findById(createdByUserId);
            }

            if (createdBy != null) {
                t.setCreatedBy(createdBy);
            } else {
                User fallback = new User();
                fallback.setId(createdByUserId);
                fallback.setFullName("�������� ���������� (ID " + createdByUserId + ")");
                t.setCreatedBy(fallback);
            }
        }

        if (t.getCreatedBy() == null && t.getUser() != null) {
            t.setCreatedBy(t.getUser());
        }

        Long budgetId = rs.getLong("budget_id");
        if (!rs.wasNull()) {
            t.setBudgetId(budgetId);
        }

        t.setCurrency(rs.getString("currency"));

        return t;
    }

    public Transaction create(Transaction tx, Connection c) throws SQLException {

        String sql = "INSERT INTO transactions (amount, type, description, created_at, category_id, account_id, user_id, currency, template_id, trans_date, budget_id, created_by_user_id) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)";

        try(PreparedStatement ps = c.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            ps.setDouble(1, tx.getAmount());
            ps.setString(2, tx.getType());
            ps.setString(3, tx.getDescription());
            ps.setTimestamp(4, Timestamp.valueOf(tx.getCreatedAt() != null ? tx.getCreatedAt() : LocalDateTime.now()));
            ps.setObject(5, tx.getCategory()!=null?tx.getCategory().getId():null);
            ps.setObject(6, tx.getAccount()!=null?tx.getAccount().getId():null);
            ps.setObject(7, tx.getUser()!=null?tx.getUser().getId():null);
            ps.setString(8, tx.getCurrency());
            ps.setObject(9, tx.getTemplateId(), Types.BIGINT);
            ps.setObject(10, tx.getTransDate() != null ? Date.valueOf(tx.getTransDate()) : null, Types.DATE);
            ps.setObject(11, tx.getBudgetId());

            ps.setObject(12, tx.getCreatedBy()!=null?tx.getCreatedBy().getId():null);

            ps.executeUpdate();

            try (ResultSet keys = ps.getGeneratedKeys()) {
                if(keys.next()) tx.setId(keys.getLong(1));
            }

            return tx;
        }
    }

 
    public Transaction update(Transaction originalTx, Transaction updatedTx, Connection c) throws SQLException {

        if (updatedTx.getId() == null || updatedTx.getUser() == null || originalTx == null || updatedTx.getBudgetId() == null) {
             throw new IllegalArgumentException("����������, ���������� ����������, ���������� ��� �������� ������� �� ��������� ��� ���������.");
        }

        updatedTx.setOriginalAccount(originalTx.getAccount());
        updatedTx.setOriginalAmount(originalTx.getAmount());
        updatedTx.setOriginalType(originalTx.getType());

        String sql = "UPDATE transactions SET amount=?, type=?, description=?, created_at=?, category_id=?, account_id=?, currency=?, template_id=?, trans_date=?, budget_id=? WHERE id=? AND budget_id=?";
        try (PreparedStatement ps = c.prepareStatement(sql)) {
             ps.setDouble(1, updatedTx.getAmount());
             ps.setString(2, updatedTx.getType());
             ps.setString(3, updatedTx.getDescription());
             ps.setTimestamp(4, Timestamp.valueOf(updatedTx.getCreatedAt()));
             ps.setObject(5, updatedTx.getCategory() != null ? updatedTx.getCategory().getId() : null);
             ps.setObject(6, updatedTx.getAccount() != null ? updatedTx.getAccount().getId() : null);
             ps.setString(7, updatedTx.getCurrency());
             ps.setObject(8, updatedTx.getTemplateId(), Types.BIGINT);
             ps.setObject(9, updatedTx.getTransDate() != null ? Date.valueOf(updatedTx.getTransDate()) : null, Types.DATE);

             ps.setObject(10, updatedTx.getBudgetId());

             ps.setLong(11, updatedTx.getId());
             ps.setLong(12, updatedTx.getBudgetId());

             int rowsAffected = ps.executeUpdate();
             if (rowsAffected == 0) {
                 throw new RuntimeException("�� ������� ������� ���������� ID " + updatedTx.getId() + ". ���� ���� �� �������� ������� " + updatedTx.getBudgetId());
             }
        }
        return updatedTx;
    }

    public Transaction update(Transaction originalTx, Transaction updatedTx) {
        try (Connection c = Db.getConnection()) {
             c.setAutoCommit(true);
             return update(originalTx, updatedTx, c);
        } catch (SQLException e) {
             e.printStackTrace();
             throw new RuntimeException("������� �� ��� ��������� ����������: " + e.getMessage());
        }
    }

    public void delete(Transaction tx, Connection c) throws SQLException {
 
        if (tx.getId() == null || tx.getUser() == null || tx.getBudgetId() == null) {
             throw new IllegalArgumentException("���������� ��� �������� ������� �� ��������� ��� ���������.");
        }

        tx.setOriginalAccount(tx.getAccount());
        tx.setOriginalAmount(tx.getAmount());
        tx.setOriginalType(tx.getType());

        String sql = "DELETE FROM transactions WHERE id=? AND budget_id=?";
        try (PreparedStatement ps = c.prepareStatement(sql)) {
             ps.setLong(1, tx.getId());
             ps.setLong(2, tx.getBudgetId());
             ps.executeUpdate();
        }
    }

    public void delete(Transaction tx) {
        try (Connection c = Db.getConnection()) {
             c.setAutoCommit(true);
             delete(tx, c);
        } catch (SQLException e) {
             e.printStackTrace();
             throw new RuntimeException("������� �� ��� ��������� ����������: " + e.getMessage());
        }
    }


    public List<Object[]> aggregateMonthlySummary(ReportParams params, Long budgetId) {
        String sql = "SELECT DATE_FORMAT(t.created_at, '%Y-%m') AS month_year, t.type, SUM(t.amount) AS total_amount, t.currency FROM transactions t WHERE t.budget_id = ? AND t.created_at BETWEEN ? AND ? AND t.type IN ('INCOME', 'EXPENSE') GROUP BY month_year, t.type, t.currency ORDER BY month_year, t.type";

        var rawDataList = new ArrayList<Object[]>();

        try (Connection conn = Db.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

                ps.setLong(1, budgetId);
                ps.setTimestamp(2, Timestamp.valueOf(params.getStartDate().atStartOfDay()));
                ps.setTimestamp(3, Timestamp.valueOf(params.getEndDate().plusDays(1).atStartOfDay().minusNanos(1)));

                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        rawDataList.add(new Object[]{
                            rs.getString("month_year"),
                            rs.getString("type"),
                            rs.getDouble("total_amount"),
                            rs.getString("currency")
                        });
                    }
                }
        } catch (SQLException e) {
                e.printStackTrace();
                throw new RuntimeException("������� �� ��� ��������� ������ �������: " + e.getMessage());
        }
        return rawDataList;
    }

    public List<Object[]> aggregateByCategorySummary(ReportParams params, Long budgetId) {
        String sql = "SELECT t.category_id, t.type, SUM(t.amount) AS total_amount, t.currency FROM transactions t WHERE t.budget_id = ? AND t.created_at BETWEEN ? AND ? AND t.type IN ('INCOME', 'EXPENSE') AND t.category_id IS NOT NULL GROUP BY t.category_id, t.type, t.currency";

        var rawDataList = new ArrayList<Object[]>();

        try (Connection conn = Db.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

                ps.setLong(1, budgetId);
                ps.setTimestamp(2, Timestamp.valueOf(params.getStartDate().atStartOfDay()));
                ps.setTimestamp(3, Timestamp.valueOf(params.getEndDate().plusDays(1).atStartOfDay().minusNanos(1)));

                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        rawDataList.add(new Object[]{
                            rs.getLong("category_id"),
                            rs.getString("type"),
                            rs.getDouble("total_amount"),
                            rs.getString("currency")
                        });
                    }
                }
        } catch (SQLException e) {
                e.printStackTrace();
                throw new RuntimeException("������� �� ��� ��������� �� ����������: " + e.getMessage());
        }
        return rawDataList;
    }
}