package ua.kpi.personal.analytics.output;

import ua.kpi.personal.model.analytics.ReportDataPoint;
import java.io.FileOutputStream;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.io.File;

import javafx.stage.FileChooser;
import javafx.stage.Window;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelRenderer implements OutputRenderer {
    
    private final Window ownerWindow;    

    public ExcelRenderer(Window ownerWindow) {
        this.ownerWindow = ownerWindow;
    }

    private File showSaveDialog(String title, String defaultFileName) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle(title);
        fileChooser.setInitialFileName(defaultFileName);
        FileChooser.ExtensionFilter extFilter = new FileChooser.ExtensionFilter("Excel files (*.xlsx)", "*.xlsx");
        fileChooser.getExtensionFilters().add(extFilter);
        return fileChooser.showSaveDialog(ownerWindow);
    }

    @Override
    public void renderReport(String reportTitle, List<ReportDataPoint> dataPoints, String summary) {
        String defaultFileName = reportTitle.replaceAll("\\s+", "_") + "_" 
                               + LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd")) + ".xlsx";
        File file = showSaveDialog("�������� ��� � Excel", defaultFileName);

        if (file != null) {
            System.out.println("��������� ���� �� �������� � XLSX...");
            try (Workbook workbook = new XSSFWorkbook();
                 FileOutputStream fos = new FileOutputStream(file)) {

                Sheet sheet = workbook.createSheet(reportTitle);
                CellStyle headerStyle = createHeaderStyle(workbook);
                CellStyle currencyStyle = createCurrencyStyle(workbook);

                int rowNum = 0;
                
                Row titleRow = sheet.createRow(rowNum++);
                titleRow.createCell(0).setCellValue(reportTitle);
               
                if (summary != null && !summary.isEmpty()) {
                    rowNum++; // ������� �����
                    Row summaryRow = sheet.createRow(rowNum++);
                    summaryRow.createCell(0).setCellValue("ϳ������:");
                    summaryRow.createCell(1).setCellValue(summary);
                }
                
                rowNum++; 

                String[] headers = {"����", "����", "��������/���. ��������"};
                Row headerRow = sheet.createRow(rowNum++);
                for (int i = 0; i < headers.length; i++) {
                    Cell cell = headerRow.createCell(i);
                    cell.setCellValue(headers[i]);
                    cell.setCellStyle(headerStyle);
                }

                for (ReportDataPoint point : dataPoints) {
                    Row row = sheet.createRow(rowNum++);
                    
                    row.createCell(0).setCellValue(point.getKey());
                    
                    Cell valueCell = row.createCell(1);
                    valueCell.setCellValue(point.getValue());
                    valueCell.setCellStyle(currencyStyle); 

                    String secondaryVal;
                    if (point.getSecondaryValue() != 0.0) {
                        secondaryVal = String.format("%.2f", point.getSecondaryValue());
                    } else {
                        secondaryVal = point.getLabel();
                    }
                    row.createCell(2).setCellValue(secondaryVal);
                }

                for (int i = 0; i < headers.length; i++) {
                    sheet.autoSizeColumn(i);
                }

                workbook.write(fos);
                System.out.printf("? ������� %d ����� �� %s ��������� ������.%n", 
                                 dataPoints.size(), file.getAbsolutePath());

            } catch (IOException e) {
                System.err.println("? ������� �������� Excel: " + e.getMessage());
                e.printStackTrace();
            }
        } else {
            System.out.println("������� ��������� ������������.");
        }
    }
    
    private CellStyle createHeaderStyle(Workbook workbook) {
        CellStyle style = workbook.createCellStyle();
        Font font = workbook.createFont();
        font.setBold(true);
        style.setFont(font);
        style.setAlignment(HorizontalAlignment.CENTER);
        style.setVerticalAlignment(VerticalAlignment.CENTER);
        return style;
    }
    
    private CellStyle createCurrencyStyle(Workbook workbook) {
        CellStyle style = workbook.createCellStyle();
        DataFormat format = workbook.createDataFormat();
        style.setDataFormat(format.getFormat("0.00")); 
        return style;
    }

}