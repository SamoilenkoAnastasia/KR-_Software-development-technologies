package ua.kpi.personal.analytics.report;

import ua.kpi.personal.model.User;
import ua.kpi.personal.model.analytics.CategoryReportRow;
import ua.kpi.personal.model.analytics.ReportDataPoint;
import ua.kpi.personal.model.analytics.ReportParams;
import ua.kpi.personal.service.AnalyticsService; 

import java.util.List;
import java.util.stream.Collectors;

public class CategoryReport extends FinancialReport {

    private final AnalyticsService analyticsService; 
    public CategoryReport(AnalyticsService analyticsService) {
        this.analyticsService = analyticsService;
    }

    @Override
    protected List<ReportDataPoint> analyze(ReportParams params, User user) {
      
        List<CategoryReportRow> rawData = analyticsService.getCategorySummaryReport(params);

        return rawData.stream()
                .map(row -> new ReportDataPoint(
                        row.categoryName(), 
                        Math.abs(row.totalAmount()), 
                        0.0,
                        row.totalAmount() < 0 ? "�������" : (row.totalAmount() > 0 ? "������/������" : "����")
                ))
                .collect(Collectors.toList());
    }

    @Override
    protected void render(List<ReportDataPoint> dataPoints) {
        if (renderer == null) {
            throw new IllegalStateException("Renderer �� �����������.");
        }
            
        double totalBalance = dataPoints.stream()
                .mapToDouble(row -> row.getLabel().equals("�������") ? -row.getValue() : row.getValue()) 
                .sum();

        String reportTitle = "��� �� ����������"; 
        String summary = String.format("������ �������: %.2f %s", totalBalance, "UAH");

        this.renderer.renderReport(reportTitle, dataPoints, summary);
    }
}