package ua.kpi.personal.controller;

import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import ua.kpi.personal.model.Account;
import ua.kpi.personal.model.Goal;
import ua.kpi.personal.model.User;
import ua.kpi.personal.repo.AccountDao;
import ua.kpi.personal.repo.GoalDao;
import ua.kpi.personal.service.GoalService;
import ua.kpi.personal.service.TransactionService;
import ua.kpi.personal.state.ApplicationSession;
import ua.kpi.personal.util.Alerts;
import java.io.IOException;
import java.util.Date;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

public class GoalsController {

    @FXML private TextField newGoalName;
    @FXML private TextField newGoalTargetAmount;
    @FXML private ChoiceBox<String> newGoalCurrency;
    @FXML private DatePicker newGoalDeadline;

    @FXML private ListView<Goal> goalsListView;
    @FXML private TextField contributionAmount;
    @FXML private ChoiceBox<Account> sourceAccountChoice;
    @FXML private Label progressLabel;

    @FXML private Label messageLabel;
    @FXML private Button backBtn;

    private GoalService goalService;
    private User user;
    private final GoalDao goalDao = new GoalDao();
    private final AccountDao accountDao = new AccountDao();

    public GoalsController() {
    }

    @FXML
    public void initialize(){
        ApplicationSession session = ApplicationSession.getInstance();
        this.user = session.getCurrentUser();

        TransactionService transactionService = session.getTransactionService();

        this.goalService = new GoalService(goalDao, accountDao, transactionService.getTransactionProcessor());

        newGoalCurrency.getItems().addAll("UAH", "USD", "EUR");
        refreshData();
    }

    private void refreshData() {
        ApplicationSession session = ApplicationSession.getInstance();
        if (user == null) return;

        goalsListView.setItems(
            FXCollections.observableArrayList(goalService.getAllGoals(user))
        );

        goalsListView.getSelectionModel().selectedItemProperty().addListener((obs, oldV, newV) -> {
            if (newV != null) {
                updateProgressDisplay(newV);

                sourceAccountChoice.setItems(
                    FXCollections.observableArrayList(
                        accountDao.findByBudgetId(session.getCurrentBudgetId()).stream()
                            .filter(acc ->
                                acc.getCurrency().equals(newV.getCurrency()) ||
                                (isCurrencyConvertible(acc.getCurrency(), newV.getCurrency()))
                            )
                            .collect(Collectors.toList())
                    )
                );

                if (!sourceAccountChoice.getItems().isEmpty()) {
                    sourceAccountChoice.getSelectionModel().selectFirst();
                } else {
                    sourceAccountChoice.getSelectionModel().clearSelection();
                }
            }
        });

        sourceAccountChoice.setItems(
             FXCollections.observableArrayList(accountDao.findByBudgetId(session.getCurrentBudgetId()))
        );
    }


    private boolean isCurrencyConvertible(String source, String target) {
        if (source.equals(target)) return true;

        boolean isSupportedPair =
            ("UAH".equals(source) && ("USD".equals(target) || "EUR".equals(target))) ||
            ("USD".equals(source) && "UAH".equals(target)) ||
            ("EUR".equals(source) && "UAH".equals(target));

        return isSupportedPair;
    }

    private void updateProgressDisplay(Goal goal) {
        double current = goal.getCurrentAmount();
        double target = goal.getTargetAmount();
        double progress = (target > 0) ? (current / target) : 0.0;
        long daysLeft = -1;
        if (goal.getDeadline() != null) {
            long diff = goal.getDeadline().getTime() - new Date().getTime();
            daysLeft = TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS);
        }

        String status = String.format("�������: %.2f / %.2f %s (%.1f%%)",
                                     current, target, goal.getCurrency(), progress * 100);

        if (current >= target) {
             status = "? ֳ�� ���������! " + status;
        } else if (daysLeft >= 0) {
            status += String.format(" | ���������� ����: %d", daysLeft);
        } else if (goal.getDeadline() != null && daysLeft < 0) {
             status += " | ����� ������!";
        }

        progressLabel.setText(status);
    }

    @FXML
    public void onCreateGoal() {

        if (!ApplicationSession.getInstance().getCurrentBudgetAccessState().canEdit()) {
            Alerts.showError("������ ����������", "� ��� ���� ���� ��� ��������� ����� � ����� ������.");
            return;
        }

        try {
            if (newGoalName.getText().trim().isEmpty() || newGoalTargetAmount.getText().trim().isEmpty() || newGoalCurrency.getValue() == null) {
                throw new IllegalArgumentException("��������� �� ����'����� ����.");
            }

            Goal goal = new Goal();
            goal.setName(newGoalName.getText());
            goal.setTargetAmount(Double.parseDouble(newGoalTargetAmount.getText()));
            goal.setCurrency(newGoalCurrency.getValue());
            goal.setDeadline(
                newGoalDeadline.getValue() != null ?
                java.sql.Date.valueOf(newGoalDeadline.getValue()) : null
            );

            goalService.createGoal(goal, user);
            messageLabel.setText("? ֳ�� ������ ��������: " + goal.getName());
            clearNewGoalFields();
            refreshData();
        } catch (NumberFormatException e) {
            messageLabel.setText("? �������: ���������� ���� ���. �������������� �����.");
        } catch (IllegalArgumentException e) {
             messageLabel.setText("? �������: " + e.getMessage());
        }
    }

    @FXML
    public void onContribute() {

        if (!ApplicationSession.getInstance().getCurrentBudgetAccessState().canAddTransaction()) {
            Alerts.showError("������ ����������", "� ��� ���� ���� ��� �������� ����� � ����� ������.");
            return;
        }

        Goal selectedGoal = goalsListView.getSelectionModel().getSelectedItem();
        Account sourceAccount = sourceAccountChoice.getValue();

        if (selectedGoal == null) { messageLabel.setText("? ������� ����."); return; }
        if (sourceAccount == null) { messageLabel.setText("? ������� ������� ��� ��������."); return; }

        try {
            double amount = Double.parseDouble(contributionAmount.getText());
            if (amount <= 0) {
                throw new IllegalArgumentException("���� ������ �� ���� ����� ����.");
            }

            goalService.contributeToGoal(selectedGoal.getId(), sourceAccount.getId(), amount, user);

            messageLabel.setText(String.format("? ������� ������ � %s �� ���� %.2f %s.",
                                                selectedGoal.getName(), amount, sourceAccount.getCurrency()));

            contributionAmount.clear();
            refreshData();

            Goal updatedGoal = goalService.getAllGoals(user).stream()
                 .filter(g -> g.getId().equals(selectedGoal.getId())).findFirst().orElse(null);
            if (updatedGoal != null) {
                 updateProgressDisplay(updatedGoal);
            }

        } catch (NumberFormatException e) {
            messageLabel.setText("? �������: ���������� ���� ������.");
        } catch (Exception e) {

            messageLabel.setText("? ������� ������: " + e.getMessage());
        }
    }

    private void clearNewGoalFields() {
        newGoalName.clear();
        newGoalTargetAmount.clear();
        newGoalDeadline.setValue(null);
    }

    @FXML
    public void onBack() throws IOException {
        ApplicationSession.getInstance().login(user);
    }
}