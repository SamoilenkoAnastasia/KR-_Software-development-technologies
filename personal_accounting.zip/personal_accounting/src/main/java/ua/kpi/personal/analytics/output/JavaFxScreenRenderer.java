package ua.kpi.personal.analytics.output;

import javafx.collections.FXCollections;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.chart.*;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.VBox; 
import ua.kpi.personal.model.analytics.ReportDataPoint;

import java.util.List;
import java.util.stream.Collectors;

public class JavaFxScreenRenderer implements OutputRenderer {

    private final TableView<ReportDataPoint> tableView;
    private final Label summaryLabel;
    private final AnchorPane chartContainer;

    private Node currentPieChart;
    private Node currentLineChart;
    private List<ReportDataPoint> lastDataPoints;

    public JavaFxScreenRenderer(TableView<ReportDataPoint> tableView, Label summaryLabel, AnchorPane chartContainer) {
        this.tableView = tableView;
        this.summaryLabel = summaryLabel;
        this.chartContainer = chartContainer;
    }

    @Override
    public void renderReport(String reportTitle, List<ReportDataPoint> dataPoints, String summary) {
        summaryLabel.setText(summary);
        this.lastDataPoints = dataPoints;

        updateTableView(dataPoints);

        renderChartsWithSelector(dataPoints, reportTitle);

        System.out.println("³���������� ���� '" + reportTitle + "' �� ������ ���������.");
    }
    
    private void renderChartsWithSelector(List<ReportDataPoint> dataPoints, String title) {
        chartContainer.getChildren().clear();

        if (dataPoints.isEmpty()) {
            chartContainer.getChildren().add(new Label("���� ����� ��� ������."));
            return;
        }

        currentPieChart = createPieChartNode(dataPoints, title);
        currentLineChart = createLineChartNode(dataPoints, title);

        ComboBox<String> chartSelector = new ComboBox<>(FXCollections.observableArrayList(
            "������� ������� (�������)",
            "˳����� ������� (�������)"
        ));
        chartSelector.getSelectionModel().selectFirst();

        AnchorPane displayPane = new AnchorPane();

        chartSelector.getSelectionModel().selectedItemProperty().addListener((obs, oldVal, newVal) -> {
            displayPane.getChildren().clear();
            if ("������� ������� (�������)".equals(newVal)) {
                addChartToPane(displayPane, currentPieChart);
            } else if ("˳����� ������� (�������)".equals(newVal)) {
                addChartToPane(displayPane, currentLineChart);
            }
        });

        VBox selectorBox = new VBox(10, chartSelector, displayPane);
        selectorBox.setPadding(new Insets(10));
        VBox.setVgrow(displayPane, javafx.scene.layout.Priority.ALWAYS);

        addChartToPane(displayPane, currentPieChart);

        chartContainer.getChildren().add(selectorBox);
        AnchorPane.setTopAnchor(selectorBox, 0.0);
        AnchorPane.setBottomAnchor(selectorBox, 0.0);
        AnchorPane.setLeftAnchor(selectorBox, 0.0);
        AnchorPane.setRightAnchor(selectorBox, 0.0);
    }

    private void addChartToPane(AnchorPane pane, Node chart) {
        pane.getChildren().add(chart);
        AnchorPane.setTopAnchor(chart, 0.0);
        AnchorPane.setBottomAnchor(chart, 0.0);
        AnchorPane.setLeftAnchor(chart, 0.0);
        AnchorPane.setRightAnchor(chart, 0.0);
    }

    private void updateTableView(List<ReportDataPoint> dataPoints) {
        tableView.setItems(FXCollections.observableList(dataPoints));

        if (tableView.getColumns().isEmpty()) {
            TableColumn<ReportDataPoint, String> keyCol = new TableColumn<>("����/�����");
            keyCol.setCellValueFactory(new PropertyValueFactory<>("key"));
            
            TableColumn<ReportDataPoint, String> valueCol = new TableColumn<>("������� �������� (UAH)");
            valueCol.setCellValueFactory(cellData -> 
                new javafx.beans.property.SimpleStringProperty(String.format("%.2f", cellData.getValue().getValue()))
            );

            TableColumn<ReportDataPoint, String> secondaryCol = new TableColumn<>("̳���/���. ��������");
            secondaryCol.setCellValueFactory(cellData -> {
                ReportDataPoint point = cellData.getValue();
                String result;
                if (point.getSecondaryValue() != 0.0) {
                    result = String.format("%.2f", point.getSecondaryValue());
                } else {
                    result = point.getLabel();
                }
                return new javafx.beans.property.SimpleStringProperty(result);
            });

            tableView.getColumns().addAll(keyCol, valueCol, secondaryCol);
        }
    }


    private Node createLineChartNode(List<ReportDataPoint> dataPoints, String title) {
       final CategoryAxis xAxis = new CategoryAxis();
       final NumberAxis yAxis = new NumberAxis();
       final LineChart<String, Number> lineChart = new LineChart<>(xAxis, yAxis);

       lineChart.setTitle("�������: " + title);
       xAxis.setLabel("�����");
       yAxis.setLabel("���� (UAH)");

       xAxis.setTickLabelRotation(90); 

       if (dataPoints.size() > 20) {
           xAxis.setTickLabelsVisible(false);
           xAxis.setLabel("����� (����� ���. � �������)");
       }


       XYChart.Series<String, Number> valueSeries = new XYChart.Series<>();
       valueSeries.setName("������� ��������"); 

       XYChart.Series<String, Number> secondarySeries = new XYChart.Series<>();
       secondarySeries.setName("��������� ��������"); 

       for (ReportDataPoint dp : dataPoints) {
           valueSeries.getData().add(new XYChart.Data<>(dp.getKey(), dp.getValue()));
           if (dp.getSecondaryValue() != 0.0) {
                secondarySeries.getData().add(new XYChart.Data<>(dp.getKey(), dp.getSecondaryValue()));
           }
       }

       lineChart.getData().add(valueSeries);
       if (!secondarySeries.getData().isEmpty()) {
            lineChart.getData().add(secondarySeries);
       }

       return lineChart; 
   }

    private Node createPieChartNode(List<ReportDataPoint> dataPoints, String title) {
        List<PieChart.Data> pieData = dataPoints.stream()
            .collect(Collectors.groupingBy(ReportDataPoint::getKey, 
                                           Collectors.summingDouble(p -> Math.abs(p.getValue()))))
            .entrySet().stream()
            .filter(entry -> entry.getValue() > 0.01)
            .map(entry -> new PieChart.Data(entry.getKey(), entry.getValue()))
            .collect(Collectors.toList());


        if (pieData.isEmpty()) {
            return new Label("����������� ����� ��� ������� �������.");
        }

        PieChart pieChart = new PieChart(FXCollections.observableList(pieData));
        pieChart.setTitle("�������: " + title);
        pieChart.setLegendVisible(true);
        
        return pieChart; 
    }
}