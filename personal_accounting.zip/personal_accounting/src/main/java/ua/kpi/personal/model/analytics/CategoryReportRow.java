package ua.kpi.personal.model.analytics;


public record CategoryReportRow(
    String categoryName,
    double totalAmount
) {}